package com.modul1.demo;

public enum TipeBarang {
    ELEKTRONIK,
    PAKAIAN,
    MAKANAN
}
